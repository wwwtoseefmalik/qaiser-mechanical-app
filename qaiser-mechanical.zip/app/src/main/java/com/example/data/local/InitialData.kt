package com.example.data.local

import com.example.data.model.CarAd
import com.example.data.model.WorkshopService

object InitialData {
    val sampleServices = listOf(
        WorkshopService(
            id = "srv_breakdown",
            title = "Emergency Roadside Breakdown",
            titleUrdu = "روڈ سائیڈ ایمرجنسی مکینک",
            shortDescription = "On-site emergency mechanic visit for car breakdown anywhere in the city.",
            detailedDescription = "Stranded on the road? Qaiser Mechanical sends a fully equipped mobile mechanic van to your exact GPS location. We fix starting issues, punctures, overheating, battery jumpstarts, belts, and fuel issues on the spot.",
            estimatedTime = "15 - 35 mins arrival",
            priceStartingPkr = 1500,
            category = "Emergency",
            iconName = "emergency",
            isPopular = true
        ),
        WorkshopService(
            id = "srv_efi",
            title = "EFI Computer Tuning & Diagnostics",
            titleUrdu = "کمپیوٹر ای ایف آئی ٹیوننگ اور اسکیننگ",
            shortDescription = "Complete OBD-II scanner diagnostics, catalytic converter wash, throttle cleaning.",
            detailedDescription = "State-of-the-art computer scanning to clear check-engine lights, test live sensor data, oxygen sensors, injector cleaning with ultrasonic bath, spark plug testing, and ECU calibrations.",
            estimatedTime = "1 - 2 hours",
            priceStartingPkr = 3500,
            category = "Mechanical",
            isPopular = true
        ),
        WorkshopService(
            id = "srv_engine",
            title = "Engine & Gearbox Overhaul",
            titleUrdu = "انجن اور گیئر باکس مرمت و اوورہال",
            shortDescription = "Expert mechanical engine repair, head gasket replacement, transmission tuning.",
            detailedDescription = "Complete engine rebuilding, compression restoration, timing chain/belt replacements, valve seating, transmission torque converter diagnostics, and oil leak eliminations.",
            estimatedTime = "1 - 3 days",
            priceStartingPkr = 15000,
            category = "Mechanical",
            isPopular = true
        ),
        WorkshopService(
            id = "srv_suspension",
            title = "Suspension & Steering Overhaul",
            titleUrdu = "سسپنشن اور کٹائی کا مکمل کام",
            shortDescription = "Shock absorbers, bushings, tie rod ends, steering rack repair & wheel alignment.",
            detailedDescription = "Eliminate cabin noise, vibration, and wandering steering. Full suspension rebuild using genuine bush kits, Japanese shock absorbers, rack and pinion steering overhauls, and axle repairs.",
            estimatedTime = "3 - 5 hours",
            priceStartingPkr = 5000,
            category = "Mechanical",
            isPopular = false
        ),
        WorkshopService(
            id = "srv_brakes",
            title = "Brake Service & Disc Turning",
            titleUrdu = "بریک پیڈز، ڈسک اور اے بی ایس چیک اپ",
            shortDescription = "Ceramic brake pads replacement, rotor disc lathing, ABS sensor diagnostics.",
            detailedDescription = "Restores 100% braking power. Ceramic brake pad fitting, computerized disc skimming to stop brake vibration, brake fluid flush with DOT4, and electronic ABS unit diagnostics.",
            estimatedTime = "1 - 2 hours",
            priceStartingPkr = 2500,
            category = "Mechanical",
            isPopular = false
        ),
        WorkshopService(
            id = "srv_ac",
            title = "Car AC Repair & Gas Refill",
            titleUrdu = "گاڑی اے سی سروس اور گیس چارجنگ",
            shortDescription = "Cooling coil replacement, compressor overhaul, leak detection & R134a gas.",
            detailedDescription = "Chill your car in hot summer. High-pressure nitrogen leak test, evaporator cooling coil clean/replacement, compressor clutch repair, and 100% pure American R134a refrigerant charge.",
            estimatedTime = "2 - 4 hours",
            priceStartingPkr = 4500,
            category = "Electrical",
            isPopular = true
        ),
        WorkshopService(
            id = "srv_inspection",
            title = "200-Point Pre-Purchase Car Inspection",
            titleUrdu = "گاڑی خریدنے سے پہلے تفصیلی معائنہ",
            shortDescription = "Paint digital gauge inspection, engine compression, accidental check, suspension test.",
            detailedDescription = "Buying a used car? Let Qaiser Mechanical inspect it before paying! Digital paint depth check (potine & accidental history), computerized OBD scan, engine blowby & compression test, suspension drive test with a full scored report.",
            estimatedTime = "45 mins",
            priceStartingPkr = 3000,
            category = "Inspection",
            isPopular = true
        ),
        WorkshopService(
            id = "srv_oil",
            title = "Periodic Oil & Filter Change Service",
            titleUrdu = "موبل آئل، فلٹرز اور پیریوڈک مینٹیننس",
            shortDescription = "Synthetic engine oil change, genuine oil & air filters, 25-point health checkup.",
            detailedDescription = "Genuine Mobil / Shell / Total / Toyota OEM synthetic engine oil, genuine oil filter, engine air filter, cabin AC filter, coolant top-up, and free 25-point visual vehicle inspection.",
            estimatedTime = "30 mins",
            priceStartingPkr = 2000,
            category = "Mechanical",
            isPopular = false
        )
    )

    val sampleCarAds = listOf(
        CarAd(
            id = "car_001",
            title = "Toyota Corolla Altis Grande 1.8 CVT-i 2022",
            brand = "Toyota",
            model = "Corolla Altis Grande",
            year = 2022,
            mileageKm = 32000,
            pricePkr = 6950000,
            city = "Lahore",
            registeredCity = "Lahore",
            transmission = "Automatic",
            fuelType = "Petrol",
            condition = "10/10 Total Genuine - Sunroof",
            description = "First owner, total genuine paint, bumper to bumper original. Maintained from authorized dealership with complete history log. Sunroof, leather seats, paddle shifters, Michelin tyres. Qaiser Mechanical verified inspection score: 96/100.",
            ownerName = "Muhammad Bilal",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1590362891988-f77804703088?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = true,
            inspectionScore = 96
        ),
        CarAd(
            id = "car_002",
            title = "Honda Civic Oriel 1.8 i-VTEC 2021",
            brand = "Honda",
            model = "Civic Oriel",
            year = 2021,
            mileageKm = 46000,
            pricePkr = 5850000,
            city = "Islamabad",
            registeredCity = "Islamabad",
            transmission = "Automatic",
            fuelType = "Petrol",
            condition = "9.5/10 Genuine Body",
            description = "Crystal Black Pearl Honda Civic Oriel. Immaculate interior, sunroof, digital instrument cluster, push start, climate control. Scratchless body, all mechanical components checked and certified by Qaiser Mechanical. Price slightly negotiable for serious buyers.",
            ownerName = "Hamza Farooq",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1606611013016-969c19ba27bb?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1606611013016-969c19ba27bb?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = true,
            inspectionScore = 94
        ),
        CarAd(
            id = "car_003",
            title = "Suzuki Alto VXL AGS 2023",
            brand = "Suzuki",
            model = "Alto VXL",
            year = 2023,
            mileageKm = 14500,
            pricePkr = 2750000,
            city = "Lahore",
            registeredCity = "Lahore",
            transmission = "Automatic",
            fuelType = "Petrol",
            condition = "Like New - 10/10",
            description = "Suzuki Alto VXL Auto (AGS) in pristine white. Fuel average 22+ km/litre within city. Dual airbags, ABS brakes, retractable mirrors, touch screen infotainment with rear view camera. Fresh oil change done at Qaiser Mechanical.",
            ownerName = "Kashif Mehmood",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = false,
            inspectionScore = 98
        ),
        CarAd(
            id = "car_004",
            title = "KIA Sportage FWD 2.0 2022",
            brand = "KIA",
            model = "Sportage FWD",
            year = 2022,
            mileageKm = 38000,
            pricePkr = 7400000,
            city = "Rawalpindi",
            registeredCity = "Islamabad",
            transmission = "Automatic",
            fuelType = "Petrol",
            condition = "Bumper to Bumper Original",
            description = "Panaromic sunroof, electric parking brake, cruise control, leather seats, projector LED headlights, daytime running lights. 100% accident-free, inspected with computerized scan by Qaiser Mechanical.",
            ownerName = "Usman Tariq",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = true,
            inspectionScore = 95
        ),
        CarAd(
            id = "car_005",
            title = "Toyota Yaris ATIV X 1.5 CVT 2021",
            brand = "Toyota",
            model = "Yaris ATIV X",
            year = 2021,
            mileageKm = 42000,
            pricePkr = 4450000,
            city = "Karachi",
            registeredCity = "Sindh",
            transmission = "Automatic",
            fuelType = "Petrol",
            condition = "Excellent 9/10 Condition",
            description = "Top of the line 1.5 ATIV X. Push start, digital climate control, eco & sport driving modes, 6 airbags. Neat and clean family used car, mechanically 100% sound.",
            ownerName = "Rehan Sheikh",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = false,
            inspectionScore = 91
        ),
        CarAd(
            id = "car_006",
            title = "Suzuki Cultus VXL 2020",
            brand = "Suzuki",
            model = "Cultus VXL",
            year = 2020,
            mileageKm = 56000,
            pricePkr = 3100000,
            city = "Faisalabad",
            registeredCity = "Punjab",
            transmission = "Manual",
            fuelType = "Petrol",
            condition = "Good Condition - Minor Touchups",
            description = "Very economical hatchback, chilling AC, alloy rims, power windows, fog lamps, power steering. Engine, gearbox, and suspension in 100% optimal condition, fully serviced at Qaiser Mechanical.",
            ownerName = "Zubair Ahmad",
            ownerPhone = "03214813830",
            primaryImageUrl = "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=800&auto=format&fit=crop&q=80",
            imageUris = listOf(
                "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=800&auto=format&fit=crop&q=80"
            ),
            isFeatured = false,
            inspectionScore = 89
        )
    )
}
