package com.example.data.model

data class WorkshopService(
    val id: String,
    val title: String,
    val titleUrdu: String,
    val shortDescription: String,
    val detailedDescription: String,
    val estimatedTime: String,
    val priceStartingPkr: Long,
    val category: String, // Mechanical, Electrical, Body, Inspection, Emergency
    val iconName: String = "build",
    val isPopular: Boolean = false,
    val featuresIncluded: List<String> = listOf(
        "Certified mechanical inspection & live diagnostics",
        "Genuine OEM / High-grade Japanese replacement parts",
        "Expert workmanship by Master Mechanic Qaiser",
        "Post-repair test drive & quality confirmation"
    )
)
