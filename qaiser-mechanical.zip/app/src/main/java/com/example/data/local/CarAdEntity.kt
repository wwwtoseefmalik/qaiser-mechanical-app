package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.CarAd

@Entity(tableName = "car_ads")
data class CarAdEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val brand: String,
    val model: String,
    val year: Int,
    val mileageKm: Int,
    val pricePkr: Long,
    val city: String,
    val registeredCity: String,
    val transmission: String,
    val fuelType: String,
    val condition: String,
    val description: String,
    val ownerName: String,
    val ownerPhone: String,
    val imageUris: List<String>,
    val primaryImageUrl: String,
    val postedTimestamp: Long,
    val isFeatured: Boolean,
    val inspectionScore: Int
) {
    fun toDomainModel(): CarAd = CarAd(
        id = id,
        title = title,
        brand = brand,
        model = model,
        year = year,
        mileageKm = mileageKm,
        pricePkr = pricePkr,
        city = city,
        registeredCity = registeredCity,
        transmission = transmission,
        fuelType = fuelType,
        condition = condition,
        description = description,
        ownerName = ownerName,
        ownerPhone = ownerPhone,
        imageUris = imageUris,
        primaryImageUrl = primaryImageUrl,
        postedTimestamp = postedTimestamp,
        isFeatured = isFeatured,
        inspectionScore = inspectionScore
    )

    companion object {
        fun fromDomainModel(ad: CarAd): CarAdEntity = CarAdEntity(
            id = ad.id,
            title = ad.title,
            brand = ad.brand,
            model = ad.model,
            year = ad.year,
            mileageKm = ad.mileageKm,
            pricePkr = ad.pricePkr,
            city = ad.city,
            registeredCity = ad.registeredCity,
            transmission = ad.transmission,
            fuelType = ad.fuelType,
            condition = ad.condition,
            description = ad.description,
            ownerName = ad.ownerName,
            ownerPhone = ad.ownerPhone,
            imageUris = ad.imageUris,
            primaryImageUrl = ad.primaryImageUrl,
            postedTimestamp = ad.postedTimestamp,
            isFeatured = ad.isFeatured,
            inspectionScore = ad.inspectionScore
        )
    }
}
