package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CarAdDao {
    @Query("SELECT * FROM car_ads ORDER BY postedTimestamp DESC")
    fun getAllAds(): Flow<List<CarAdEntity>>

    @Query("SELECT * FROM car_ads WHERE id = :id")
    suspend fun getAdById(id: String): CarAdEntity?

    @Query("SELECT * FROM car_ads WHERE isFeatured = 1 ORDER BY postedTimestamp DESC")
    fun getFeaturedAds(): Flow<List<CarAdEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAd(ad: CarAdEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(ads: List<CarAdEntity>)

    @Update
    suspend fun updateAd(ad: CarAdEntity)

    @Delete
    suspend fun deleteAd(ad: CarAdEntity)

    @Query("DELETE FROM car_ads WHERE id = :id")
    suspend fun deleteAdById(id: String)

    @Query("SELECT COUNT(*) FROM car_ads")
    suspend fun getAdsCount(): Int
}
