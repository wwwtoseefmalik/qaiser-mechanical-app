package com.example.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

data class AppUser(
    val uid: String,
    val email: String,
    val displayName: String,
    val phoneNumber: String = "",
    val isAnonymous: Boolean = false
)

class AuthRepository {
    private val auth: FirebaseAuth? by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    private val _currentUser = MutableStateFlow<AppUser?>(null)
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    init {
        checkCurrentUser()
    }

    private fun checkCurrentUser() {
        val fbUser = auth?.currentUser
        if (fbUser != null) {
            _currentUser.value = AppUser(
                uid = fbUser.uid,
                email = fbUser.email ?: "",
                displayName = fbUser.displayName ?: (fbUser.email?.substringBefore("@") ?: "User"),
                phoneNumber = fbUser.phoneNumber ?: "",
                isAnonymous = fbUser.isAnonymous
            )
        } else {
            // Check if mock logged in session
            _currentUser.value = null
        }
    }

    suspend fun login(email: String, pass: String): Result<AppUser> {
        return try {
            val fb = auth
            if (fb != null) {
                val result = fb.signInWithEmailAndPassword(email, pass).await()
                val user = result.user
                val appUser = AppUser(
                    uid = user?.uid ?: "user_${System.currentTimeMillis()}",
                    email = user?.email ?: email,
                    displayName = user?.displayName ?: email.substringBefore("@")
                )
                _currentUser.value = appUser
                Result.success(appUser)
            } else {
                // Local fallback mode
                val appUser = AppUser(
                    uid = "local_${email.hashCode()}",
                    email = email,
                    displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                )
                _currentUser.value = appUser
                Result.success(appUser)
            }
        } catch (e: Exception) {
            // If Firebase configuration is not present (no google-services.json), allow seamless offline login with simulated account
            if (e.message?.contains("FirebaseApp") == true || e.message?.contains("google-services") == true || auth == null) {
                val appUser = AppUser(
                    uid = "local_${email.hashCode()}",
                    email = email,
                    displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                )
                _currentUser.value = appUser
                Result.success(appUser)
            } else {
                Result.failure(e)
            }
        }
    }

    suspend fun register(name: String, email: String, pass: String, phone: String = ""): Result<AppUser> {
        return try {
            val fb = auth
            if (fb != null) {
                val result = fb.createUserWithEmailAndPassword(email, pass).await()
                val user = result.user
                val appUser = AppUser(
                    uid = user?.uid ?: "user_${System.currentTimeMillis()}",
                    email = user?.email ?: email,
                    displayName = name.ifBlank { email.substringBefore("@") },
                    phoneNumber = phone
                )
                _currentUser.value = appUser
                Result.success(appUser)
            } else {
                val appUser = AppUser(
                    uid = "local_${email.hashCode()}",
                    email = email,
                    displayName = name.ifBlank { email.substringBefore("@") },
                    phoneNumber = phone
                )
                _currentUser.value = appUser
                Result.success(appUser)
            }
        } catch (e: Exception) {
            if (e.message?.contains("FirebaseApp") == true || e.message?.contains("google-services") == true || auth == null) {
                val appUser = AppUser(
                    uid = "local_${email.hashCode()}",
                    email = email,
                    displayName = name.ifBlank { email.substringBefore("@") },
                    phoneNumber = phone
                )
                _currentUser.value = appUser
                Result.success(appUser)
            } else {
                Result.failure(e)
            }
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        return try {
            val fb = auth
            if (fb != null) {
                fb.sendPasswordResetEmail(email).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit) // Allow user notification even in offline demo mode
        }
    }

    fun continueAsGuest() {
        val guestUser = AppUser(
            uid = "guest_${System.currentTimeMillis()}",
            email = "customer@qaisermechanical.com",
            displayName = "Valued Customer",
            isAnonymous = true
        )
        _currentUser.value = guestUser
    }

    fun logout() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            // ignore
        }
        _currentUser.value = null
    }
}
