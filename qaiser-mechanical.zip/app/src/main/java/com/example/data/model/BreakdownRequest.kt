package com.example.data.model

data class BreakdownRequest(
    val id: String = java.util.UUID.randomUUID().toString(),
    val carModel: String = "",
    val issueType: String = "",
    val description: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val address: String = "",
    val contactPhone: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val mapsUrl: String
        get() = if (latitude != null && longitude != null) {
            "https://maps.google.com/?q=$latitude,$longitude"
        } else ""
}
