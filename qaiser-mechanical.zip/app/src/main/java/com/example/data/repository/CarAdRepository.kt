package com.example.data.repository

import com.example.data.local.CarAdDao
import com.example.data.local.CarAdEntity
import com.example.data.local.InitialData
import com.example.data.model.CarAd
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class CarAdRepository(
    private val carAdDao: CarAdDao
) {
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() {
        val count = carAdDao.getAdsCount()
        if (count == 0) {
            val entities = InitialData.sampleCarAds.map { CarAdEntity.fromDomainModel(it) }
            carAdDao.insertAll(entities)
        }
    }

    fun getAllAds(): Flow<List<CarAd>> {
        return carAdDao.getAllAds().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun getFeaturedAds(): Flow<List<CarAd>> {
        return carAdDao.getFeaturedAds().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    suspend fun getAdById(id: String): CarAd? {
        return carAdDao.getAdById(id)?.toDomainModel()
    }

    suspend fun postCarAd(ad: CarAd): Result<String> {
        return try {
            // Save locally in Room
            carAdDao.insertAd(CarAdEntity.fromDomainModel(ad))

            // Attempt Firestore cloud sync if available
            try {
                firestore?.collection("car_ads")?.document(ad.id)?.set(ad)?.await()
            } catch (e: Exception) {
                // Ignore cloud failure in offline/preview mode
            }

            Result.success(ad.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAd(id: String) {
        carAdDao.deleteAdById(id)
        try {
            firestore?.collection("car_ads")?.document(id)?.delete()
        } catch (e: Exception) {
            // ignore
        }
    }
}
