package com.example.data.model

data class CarAd(
    val id: String,
    val title: String,
    val brand: String,
    val model: String,
    val year: Int,
    val mileageKm: Int,
    val pricePkr: Long,
    val city: String,
    val registeredCity: String = "Punjab",
    val transmission: String = "Automatic", // Automatic, Manual
    val fuelType: String = "Petrol", // Petrol, Diesel, Hybrid, Electric
    val condition: String = "Used - 9/10 Bumper to Bumper",
    val description: String = "",
    val ownerName: String = "Owner",
    val ownerPhone: String = "03214813830",
    val imageUris: List<String> = emptyList(),
    val primaryImageUrl: String = "",
    val postedTimestamp: Long = System.currentTimeMillis(),
    val isFeatured: Boolean = false,
    val inspectionScore: Int = 92
) {
    val formattedPrice: String
        get() {
            return when {
                pricePkr >= 10_000_000 -> {
                    val crore = pricePkr / 10_000_000.0
                    "PKR ${String.format("%.2f", crore)} Crore"
                }
                pricePkr >= 100_000 -> {
                    val lac = pricePkr / 100_000.0
                    "PKR ${String.format("%.2f", lac)} Lacs"
                }
                else -> "PKR $pricePkr"
            }
        }

    val formattedMileage: String
        get() = "${String.format("%,d", mileageKm)} km"
}
