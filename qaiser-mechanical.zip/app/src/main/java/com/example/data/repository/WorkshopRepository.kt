package com.example.data.repository

import com.example.data.local.InitialData
import com.example.data.model.BreakdownRequest
import com.example.data.model.WorkshopService
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class WorkshopRepository {
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    private val _services = MutableStateFlow(InitialData.sampleServices)
    val services: Flow<List<WorkshopService>> = _services.asStateFlow()

    private val _breakdownRequests = MutableStateFlow<List<BreakdownRequest>>(emptyList())
    val breakdownRequests: Flow<List<BreakdownRequest>> = _breakdownRequests.asStateFlow()

    fun getServiceById(id: String): WorkshopService? {
        return _services.value.find { it.id == id }
    }

    suspend fun submitBreakdownRequest(request: BreakdownRequest): Result<String> {
        return try {
            _breakdownRequests.value = listOf(request) + _breakdownRequests.value
            try {
                firestore?.collection("breakdowns")?.document(request.id)?.set(request)?.await()
            } catch (e: Exception) {
                // Ignore cloud sync if offline
            }
            Result.success(request.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
