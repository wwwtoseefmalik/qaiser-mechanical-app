package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CarAd
import com.example.data.repository.CarAdRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class PostAdState(
    val title: String = "",
    val brand: String = "Toyota",
    val model: String = "",
    val year: String = "2022",
    val mileage: String = "",
    val price: String = "",
    val city: String = "Lahore",
    val registeredCity: String = "Lahore",
    val condition: String = "Used - 9/10 Condition",
    val description: String = "",
    val ownerName: String = "",
    val ownerPhone: String = "03214813830",
    val imageUris: List<String> = emptyList(),
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val isSuccess: Boolean = false
)

class MarketplaceViewModel(
    private val carAdRepository: CarAdRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedBrand = MutableStateFlow("All")
    val selectedBrand: StateFlow<String> = _selectedBrand.asStateFlow()

    private val _selectedCity = MutableStateFlow("All")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val allAdsFlow = carAdRepository.getAllAds()

    val featuredAds = carAdRepository.getFeaturedAds().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val filteredAds: StateFlow<List<CarAd>> = combine(
        allAdsFlow,
        _searchQuery,
        _selectedBrand,
        _selectedCity
    ) { ads, query, brand, city ->
        ads.filter { ad ->
            val matchesQuery = query.isBlank() ||
                    ad.title.contains(query, ignoreCase = true) ||
                    ad.brand.contains(query, ignoreCase = true) ||
                    ad.model.contains(query, ignoreCase = true) ||
                    ad.city.contains(query, ignoreCase = true)

            val matchesBrand = brand == "All" || ad.brand.equals(brand, ignoreCase = true)
            val matchesCity = city == "All" || ad.city.equals(city, ignoreCase = true)

            matchesQuery && matchesBrand && matchesCity
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _postAdState = MutableStateFlow(PostAdState())
    val postAdState: StateFlow<PostAdState> = _postAdState.asStateFlow()

    fun onSearchQueryChanged(q: String) {
        _searchQuery.value = q
    }

    fun onBrandSelected(brand: String) {
        _selectedBrand.value = brand
    }

    fun onCitySelected(city: String) {
        _selectedCity.value = city
    }

    fun updatePostAdForm(
        title: String? = null,
        brand: String? = null,
        model: String? = null,
        year: String? = null,
        mileage: String? = null,
        price: String? = null,
        city: String? = null,
        registeredCity: String? = null,
        condition: String? = null,
        description: String? = null,
        ownerName: String? = null,
        ownerPhone: String? = null
    ) {
        _postAdState.value = _postAdState.value.copy(
            title = title ?: _postAdState.value.title,
            brand = brand ?: _postAdState.value.brand,
            model = model ?: _postAdState.value.model,
            year = year ?: _postAdState.value.year,
            mileage = mileage ?: _postAdState.value.mileage,
            price = price ?: _postAdState.value.price,
            city = city ?: _postAdState.value.city,
            registeredCity = registeredCity ?: _postAdState.value.registeredCity,
            condition = condition ?: _postAdState.value.condition,
            description = description ?: _postAdState.value.description,
            ownerName = ownerName ?: _postAdState.value.ownerName,
            ownerPhone = ownerPhone ?: _postAdState.value.ownerPhone
        )
    }

    fun addImageUri(uri: String) {
        val currentList = _postAdState.value.imageUris
        if (!currentList.contains(uri)) {
            _postAdState.value = _postAdState.value.copy(imageUris = currentList + uri)
        }
    }

    fun removeImageUri(uri: String) {
        _postAdState.value = _postAdState.value.copy(
            imageUris = _postAdState.value.imageUris.filter { it != uri }
        )
    }

    fun submitAd() {
        val state = _postAdState.value
        if (state.title.isBlank() || state.price.isBlank() || state.ownerPhone.isBlank()) {
            _postAdState.value = state.copy(errorMessage = "Please fill in Car Title, Price, and Contact Number")
            return
        }

        val priceClean = state.price.replace(",", "").replace(".", "").trim().toLongOrNull() ?: 0L
        val mileageClean = state.mileage.replace(",", "").trim().toIntOrNull() ?: 0
        val yearClean = state.year.trim().toIntOrNull() ?: 2022

        _postAdState.value = state.copy(isSubmitting = true, errorMessage = null)

        viewModelScope.launch {
            val primaryImg = if (state.imageUris.isNotEmpty()) state.imageUris.first() else "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800&auto=format&fit=crop&q=80"
            val newAd = CarAd(
                id = "ad_${UUID.randomUUID().toString().take(8)}",
                title = state.title,
                brand = state.brand,
                model = state.model.ifBlank { state.title },
                year = yearClean,
                mileageKm = mileageClean,
                pricePkr = priceClean,
                city = state.city,
                registeredCity = state.registeredCity,
                condition = state.condition,
                description = state.description,
                ownerName = state.ownerName.ifBlank { "Owner" },
                ownerPhone = state.ownerPhone,
                imageUris = if (state.imageUris.isNotEmpty()) state.imageUris else listOf(primaryImg),
                primaryImageUrl = primaryImg,
                isFeatured = false,
                inspectionScore = (88..98).random()
            )

            carAdRepository.postCarAd(newAd)
            _postAdState.value = PostAdState(isSuccess = true)
        }
    }

    fun resetPostForm() {
        _postAdState.value = PostAdState()
    }
}
