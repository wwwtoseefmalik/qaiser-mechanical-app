package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Qaiser Mechanical - Automotive Theme Colors
val NavyDark = Color(0xFF0A1128)
val NavyPrimary = Color(0xFF001F54)
val NavySecondary = Color(0xFF034078)
val SlateBlue = Color(0xFF1282A2)
val GoldAccent = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFCD34D)
val AmberDark = Color(0xFFD97706)
val EmergencyRed = Color(0xFFDC2626)
val EmergencyRedDark = Color(0xFF991B1B)
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppDark = Color(0xFF128C7E)

val CharcoalDark = Color(0xFF0F172A)
val CharcoalCardDark = Color(0xFF1E293B)
val CharcoalBorderDark = Color(0xFF334155)

val SlateLight = Color(0xFFF1F5F9)
val SlateCardLight = Color(0xFFFFFFFF)
val SlateBorderLight = Color(0xFFE2E8F0)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

