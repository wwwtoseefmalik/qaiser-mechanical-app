package com.example.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySecondary

data class NavItem(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val isEmergency: Boolean = false
)

@Composable
fun AppBottomBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        NavItem(Screen.Home.route, "Home", Icons.Default.Home),
        NavItem(Screen.Marketplace.route, "Buy/Sell", Icons.Default.DirectionsCar),
        NavItem(Screen.Emergency.route, "SOS Breakdown", Icons.Default.Warning, isEmergency = true),
        NavItem(Screen.Services.route, "Services", Icons.Default.Build),
        NavItem(Screen.Profile.route, "Profile", Icons.Default.Person)
    )

    NavigationBar(
        containerColor = NavyDark,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route

            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        modifier = Modifier.size(if (item.isEmergency) 26.dp else 22.dp),
                        tint = if (item.isEmergency) {
                            if (selected) EmergencyRed else Color(0xFFFF6B6B)
                        } else {
                            if (selected) GoldAccent else Color(0xFF94A3B8)
                        }
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 11.sp,
                        color = if (selected) {
                            if (item.isEmergency) Color(0xFFFF6B6B) else GoldAccent
                        } else {
                            Color(0xFF94A3B8)
                        }
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = if (item.isEmergency) Color(0x33DC2626) else NavySecondary,
                    selectedIconColor = if (item.isEmergency) EmergencyRed else GoldAccent,
                    selectedTextColor = if (item.isEmergency) Color(0xFFFF6B6B) else GoldAccent,
                    unselectedIconColor = Color(0xFF94A3B8),
                    unselectedTextColor = Color(0xFF94A3B8)
                )
            )
        }
    }
}
