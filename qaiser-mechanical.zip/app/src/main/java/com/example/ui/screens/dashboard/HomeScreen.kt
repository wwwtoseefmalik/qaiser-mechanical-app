package com.example.ui.screens.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CarAd
import com.example.data.model.WorkshopService
import com.example.ui.components.CarCard
import com.example.ui.navigation.Screen
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySecondary
import com.example.ui.theme.SlateBlue
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.WorkshopViewModel
import com.example.util.ContactHelper

@Composable
fun HomeScreen(
    marketplaceViewModel: MarketplaceViewModel,
    workshopViewModel: WorkshopViewModel,
    onNavigateToEmergency: () -> Unit,
    onNavigateToMarketplace: () -> Unit,
    onNavigateToPostAd: () -> Unit,
    onNavigateToServices: () -> Unit,
    onNavigateToCarDetail: (String) -> Unit,
    onNavigateToServiceDetail: (String) -> Unit
) {
    val context = LocalContext.current
    val featuredCars by marketplaceViewModel.featuredAds.collectAsState()
    val allCars by marketplaceViewModel.filteredAds.collectAsState()
    val services by workshopViewModel.services.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Hero Workshop Banner
        item {
            WorkshopHeroHeader(
                onCallClick = { ContactHelper.callMechanic(context) },
                onWhatsAppClick = { ContactHelper.openWhatsApp(context, message = "السلام علیکم قیصر بھائی! مجھے معلومات چاہیے تھیں۔") }
            )
        }

        // Emergency Breakdown Card (Prominent Call Mechanic Qaiser)
        item {
            EmergencyRoadsideBanner(
                onEmergencySOSClick = onNavigateToEmergency,
                onDirectCallClick = { ContactHelper.callMechanic(context) },
                onWhatsAppLocationClick = onNavigateToEmergency
            )
        }

        // Quick Actions Grid
        item {
            QuickActionsSection(
                onPostAdClick = onNavigateToPostAd,
                onBuyCarsClick = onNavigateToMarketplace,
                onEmergencyClick = onNavigateToEmergency,
                onServicesClick = onNavigateToServices
            )
        }

        // Featured Cars For Sale Header
        item {
            SectionHeader(
                title = "Featured Cars for Sale",
                subtitle = "Inspected & Certified by Qaiser Mechanical",
                onSeeAllClick = onNavigateToMarketplace
            )
        }

        // Featured Cars Horizontal Scroll
        item {
            val displayCars = if (featuredCars.isNotEmpty()) featuredCars else allCars.take(4)
            if (displayCars.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Loading cars for sale...", color = Color.Gray, fontSize = 13.sp)
                }
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(displayCars) { car ->
                        FeaturedCarItem(
                            carAd = car,
                            onClick = { onNavigateToCarDetail(car.id) }
                        )
                    }
                }
            }
        }

        // Workshop Mechanical Services Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            SectionHeader(
                title = "Specialized Auto Workshop Services",
                subtitle = "Engine, Transmission, Suspension & Diagnostic Experts",
                onSeeAllClick = onNavigateToServices
            )
        }

        // Top Services list
        items(services.take(4)) { service ->
            WorkshopServiceItemCard(
                service = service,
                onClick = { onNavigateToServiceDetail(service.id) },
                onBookClick = {
                    ContactHelper.bookServiceOnWhatsApp(context, service.title, "", "Earliest Slot")
                }
            )
        }

        // Workshop Location & Verified Guarantee Footer Card
        item {
            WorkshopTrustFooterCard(
                onCallClick = { ContactHelper.callMechanic(context) }
            )
        }
    }
}

@Composable
fun WorkshopHeroHeader(
    onCallClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.workshop_banner),
            contentDescription = "Qaiser Mechanical Workshop",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            NavyDark.copy(alpha = 0.85f),
                            NavyDark.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = GoldAccent,
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = "CERTIFIED MASTER MECHANIC",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NavyDark,
                        fontSize = 10.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "QAISER MECHANICAL",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 0.5.sp
                )
            )

            Text(
                text = "گاڑی کی مکمل مکینیکل، الیکٹریکل مرمت، آن روڈ ایمرجنسی اور کار مارکیٹ",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFFE2E8F0),
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onCallClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAccent,
                        contentColor = NavyDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Call",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("0321-4813830", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WhatsAppGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("WhatsApp", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun EmergencyRoadsideBanner(
    onEmergencySOSClick: () -> Unit,
    onDirectCallClick: () -> Unit,
    onWhatsAppLocationClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = EmergencyRed),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF991B1B), Color(0xFFDC2626), Color(0xFFB91C1C))
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color.White.copy(alpha = 0.25f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Breakdown SOS",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "EMERGENCY ROADSIDE BREAKDOWN",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        )
                        Text(
                            text = "ہماری گاڑی یہاں آکر ٹھیک کر دیں (Share GPS Location)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.95f),
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onDirectCallClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = EmergencyRed
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Call",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Qaiser", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onWhatsAppLocationClick,
                        modifier = Modifier.weight(1.2f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAccent,
                            contentColor = NavyDark
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Send Location", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionsSection(
    onPostAdClick: () -> Unit,
    onBuyCarsClick: () -> Unit,
    onEmergencyClick: () -> Unit,
    onServicesClick: () -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickActionItem(
                title = "Sell Car (Post Ad)",
                urduText = "گاڑی بیچیں",
                icon = Icons.Default.AddCircle,
                iconColor = GoldAccent,
                backgroundColor = NavyDark,
                modifier = Modifier.weight(1f),
                onClick = onPostAdClick
            )

            QuickActionItem(
                title = "Buy Cars (Market)",
                urduText = "گاڑیاں خریدیں",
                icon = Icons.Default.DirectionsCar,
                iconColor = SlateBlue,
                backgroundColor = Color.White,
                modifier = Modifier.weight(1f),
                onClick = onBuyCarsClick
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickActionItem(
                title = "Breakdown SOS",
                urduText = "آن روڈ مکینک",
                icon = Icons.Default.Warning,
                iconColor = Color.White,
                backgroundColor = EmergencyRed,
                isDarkBg = true,
                modifier = Modifier.weight(1f),
                onClick = onEmergencyClick
            )

            QuickActionItem(
                title = "Workshop Services",
                urduText = "مکینیکل سروسز",
                icon = Icons.Default.Build,
                iconColor = NavyPrimary,
                backgroundColor = Color.White,
                modifier = Modifier.weight(1f),
                onClick = onServicesClick
            )
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    urduText: String,
    icon: ImageVector,
    iconColor: Color,
    backgroundColor: Color,
    isDarkBg: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(92.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(
                            if (isDarkBg || backgroundColor == NavyDark) Color.White.copy(alpha = 0.2f)
                            else Color(0xFFF1F5F9),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = urduText,
                    fontSize = 11.sp,
                    color = if (backgroundColor == NavyDark || isDarkBg) GoldAccent else Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (backgroundColor == NavyDark || isDarkBg) Color.White else NavyDark,
                    fontSize = 12.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    onSeeAllClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF64748B),
                        fontSize = 11.sp
                    )
                )
            }
        }

        TextButton(onClick = onSeeAllClick) {
            Text("View All", color = NavySecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "View All",
                modifier = Modifier.size(14.dp),
                tint = NavySecondary
            )
        }
    }
}

@Composable
fun FeaturedCarItem(
    carAd: CarAd,
    onClick: () -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .width(260.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                AsyncImage(
                    model = carAd.primaryImageUrl.ifBlank { "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=800&auto=format&fit=crop&q=80" },
                    contentDescription = carAd.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                Surface(
                    color = GoldAccent,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "FEATURED",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 9.sp,
                            color = NavyDark
                        )
                    )
                }

                Surface(
                    color = NavyDark.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = carAd.formattedPrice,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = carAd.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = NavyDark
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${carAd.city} • ${carAd.year} • ${carAd.formattedMileage}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                Spacer(modifier = Modifier.height(8.dp))

                ElevatedButton(
                    onClick = {
                        ContactHelper.contactSellerForCarAd(
                            context = context,
                            sellerPhone = carAd.ownerPhone,
                            carTitle = carAd.title,
                            priceFormatted = carAd.formattedPrice,
                            adId = carAd.id
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = WhatsAppGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text("Chat via WhatsApp", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun WorkshopServiceItemCard(
    service: WorkshopService,
    onClick: () -> Unit,
    onBookClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(Color(0xFFE0F2FE), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = service.title,
                    tint = NavySecondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = service.title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = NavyDark,
                        fontSize = 13.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = service.titleUrdu,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = GoldAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Starting from PKR ${String.format("%,d", service.priceStartingPkr)} • ${service.estimatedTime}",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            ElevatedButton(
                onClick = onBookClick,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.elevatedButtonColors(
                    containerColor = NavyDark,
                    contentColor = GoldAccent
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("Book", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun WorkshopTrustFooterCard(
    onCallClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Guarantee",
                    tint = GoldAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Qaiser Mechanical Guarantee",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "100% Genuine Japanese & OEM Parts",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "📍 Workshop: Main Automotive Hub, Lahore, Pakistan\n🕒 Timings: 24/7 Emergency Helpline Available",
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onCallClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldAccent,
                    contentColor = NavyDark
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "Helpline",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Direct Call: +923214813830", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}
