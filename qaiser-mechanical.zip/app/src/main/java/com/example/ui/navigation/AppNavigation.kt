package com.example.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppTopBar
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.dashboard.HomeScreen
import com.example.ui.screens.emergency.EmergencyBreakdownScreen
import com.example.ui.screens.marketplace.CarDetailScreen
import com.example.ui.screens.marketplace.MarketplaceFeedScreen
import com.example.ui.screens.marketplace.PostCarAdScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.services.ServiceDetailScreen
import com.example.ui.screens.services.ServicesScreen
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.EmergencyViewModel
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.WorkshopViewModel

@Composable
fun AppNavigation(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    marketplaceViewModel: MarketplaceViewModel,
    workshopViewModel: WorkshopViewModel,
    emergencyViewModel: EmergencyViewModel
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val isAuthScreen = currentRoute in listOf(
        Screen.Login.route,
        Screen.Register.route,
        Screen.ForgotPassword.route
    )

    val isDetailOrPostScreen = currentRoute in listOf(
        Screen.PostAd.route,
        Screen.CarDetail.route,
        Screen.ServiceDetail.route
    ) || (currentRoute?.startsWith("car_detail") == true) || (currentRoute?.startsWith("service_detail") == true)

    val showBottomBar = !isAuthScreen && !isDetailOrPostScreen
    val showTopBar = !isAuthScreen && !isDetailOrPostScreen

    val topBarTitle = when (currentRoute) {
        Screen.Home.route -> "Qaiser Mechanical"
        Screen.Marketplace.route -> "Car Marketplace"
        Screen.Emergency.route -> "SOS Breakdown"
        Screen.Services.route -> "Workshop Services"
        Screen.Profile.route -> "Account & Workshop"
        else -> "Qaiser Mechanical"
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                AppTopBar(
                    title = topBarTitle,
                    canNavigateBack = false,
                    showCallAction = true
                )
            }
        },
        bottomBar = {
            if (showBottomBar) {
                AppBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // Auth flow
            composable(Screen.Login.route) {
                LoginScreen(
                    authViewModel = authViewModel,
                    onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                    onNavigateToForgotPassword = { navController.navigate(Screen.ForgotPassword.route) },
                    onLoginSuccess = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Register.route) {
                RegisterScreen(
                    authViewModel = authViewModel,
                    onNavigateToLogin = { navController.popBackStack() },
                    onRegisterSuccess = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Register.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.ForgotPassword.route) {
                ForgotPasswordScreen(
                    authViewModel = authViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Main Dashboard
            composable(Screen.Home.route) {
                HomeScreen(
                    marketplaceViewModel = marketplaceViewModel,
                    workshopViewModel = workshopViewModel,
                    onNavigateToEmergency = { navController.navigate(Screen.Emergency.route) },
                    onNavigateToMarketplace = { navController.navigate(Screen.Marketplace.route) },
                    onNavigateToPostAd = { navController.navigate(Screen.PostAd.route) },
                    onNavigateToServices = { navController.navigate(Screen.Services.route) },
                    onNavigateToCarDetail = { carId ->
                        navController.navigate(Screen.CarDetail.createRoute(carId))
                    },
                    onNavigateToServiceDetail = { serviceId ->
                        navController.navigate(Screen.ServiceDetail.createRoute(serviceId))
                    }
                )
            }

            // Emergency Breakdown
            composable(Screen.Emergency.route) {
                EmergencyBreakdownScreen(
                    viewModel = emergencyViewModel
                )
            }

            // Marketplace
            composable(Screen.Marketplace.route) {
                MarketplaceFeedScreen(
                    marketplaceViewModel = marketplaceViewModel,
                    onNavigateToPostAd = { navController.navigate(Screen.PostAd.route) },
                    onNavigateToCarDetail = { carId ->
                        navController.navigate(Screen.CarDetail.createRoute(carId))
                    }
                )
            }

            // Post Ad
            composable(Screen.PostAd.route) {
                PostCarAdScreen(
                    marketplaceViewModel = marketplaceViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Car Detail
            composable(
                route = Screen.CarDetail.route,
                arguments = listOf(navArgument("adId") { type = NavType.StringType })
            ) { backStackEntry ->
                val adId = backStackEntry.arguments?.getString("adId") ?: ""
                CarDetailScreen(
                    adId = adId,
                    marketplaceViewModel = marketplaceViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Services
            composable(Screen.Services.route) {
                ServicesScreen(
                    workshopViewModel = workshopViewModel,
                    onNavigateToServiceDetail = { serviceId ->
                        navController.navigate(Screen.ServiceDetail.createRoute(serviceId))
                    }
                )
            }

            // Service Detail
            composable(
                route = Screen.ServiceDetail.route,
                arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
            ) { backStackEntry ->
                val serviceId = backStackEntry.arguments?.getString("serviceId") ?: ""
                ServiceDetailScreen(
                    serviceId = serviceId,
                    workshopViewModel = workshopViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Profile
            composable(Screen.Profile.route) {
                ProfileScreen(
                    authViewModel = authViewModel,
                    onNavigateToLogin = { navController.navigate(Screen.Login.route) }
                )
            }
        }
    }
}
