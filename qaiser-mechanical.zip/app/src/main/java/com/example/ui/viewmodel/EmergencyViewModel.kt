package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BreakdownRequest
import com.example.data.repository.WorkshopRepository
import com.example.util.ContactHelper
import com.example.util.LocationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EmergencyBreakdownState(
    val carModel: String = "",
    val issueType: String = "Starting Issue / Battery Dead",
    val issueDetails: String = "",
    val contactPhone: String = "",
    val isFetchingLocation: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val resolvedAddress: String = "",
    val isSubmitting: Boolean = false,
    val statusMessage: String? = null
)

class EmergencyViewModel(
    private val workshopRepository: WorkshopRepository
) : ViewModel() {

    private val _state = MutableStateFlow(EmergencyBreakdownState())
    val state: StateFlow<EmergencyBreakdownState> = _state.asStateFlow()

    val commonIssues = listOf(
        "Starting Issue / Battery Dead",
        "Engine Overheating / Radiator Steam",
        "Tyre Puncture / Burst",
        "Clutch / Gearbox Stuck",
        "Brake Failure / Fluid Leak",
        "Fuel Pump / Petrol Empty",
        "Accidental Breakdown",
        "Electrical / Wiring Short Circuit",
        "Other Mechanical Problem"
    )

    fun onCarModelChanged(car: String) {
        _state.value = _state.value.copy(carModel = car)
    }

    fun onIssueTypeSelected(issue: String) {
        _state.value = _state.value.copy(issueType = issue)
    }

    fun onIssueDetailsChanged(details: String) {
        _state.value = _state.value.copy(issueDetails = details)
    }

    fun onContactPhoneChanged(phone: String) {
        _state.value = _state.value.copy(contactPhone = phone)
    }

    fun fetchCurrentGpsLocation(context: Context) {
        _state.value = _state.value.copy(isFetchingLocation = true, statusMessage = "Fetching GPS coordinates...")
        viewModelScope.launch {
            val location = LocationHelper.getCurrentLocation(context)
            if (location != null) {
                val address = LocationHelper.getAddressFromCoordinates(context, location.latitude, location.longitude)
                _state.value = _state.value.copy(
                    isFetchingLocation = false,
                    latitude = location.latitude,
                    longitude = location.longitude,
                    resolvedAddress = address,
                    statusMessage = "📍 Location acquired: $address"
                )
            } else {
                _state.value = _state.value.copy(
                    isFetchingLocation = false,
                    statusMessage = "Could not fetch GPS. Please ensure Location is enabled."
                )
            }
        }
    }

    fun sendBreakdownRequestViaWhatsApp(context: Context) {
        val s = _state.value
        val request = BreakdownRequest(
            carModel = s.carModel,
            issueType = s.issueType,
            description = s.issueDetails,
            latitude = s.latitude,
            longitude = s.longitude,
            address = s.resolvedAddress,
            contactPhone = s.contactPhone
        )

        viewModelScope.launch {
            workshopRepository.submitBreakdownRequest(request)
        }

        ContactHelper.sendBreakdownLocationOnWhatsApp(
            context = context,
            carModel = s.carModel,
            issue = s.issueType,
            details = s.issueDetails,
            latitude = s.latitude,
            longitude = s.longitude,
            address = s.resolvedAddress.ifBlank { "Breakdown Location" }
        )
    }

    fun callMechanicDirectly(context: Context) {
        ContactHelper.callMechanic(context)
    }
}
