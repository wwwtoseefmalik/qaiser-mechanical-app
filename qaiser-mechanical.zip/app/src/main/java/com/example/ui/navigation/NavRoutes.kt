package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object ForgotPassword : Screen("forgot_password")
    
    // Main Tabs / Destinations
    object Home : Screen("home")
    object Emergency : Screen("emergency")
    object Marketplace : Screen("marketplace")
    object Services : Screen("services")
    object Profile : Screen("profile")
    
    // Sub-screens
    object PostAd : Screen("post_ad")
    object CarDetail : Screen("car_detail/{adId}") {
        fun createRoute(adId: String) = "car_detail/$adId"
    }
    object ServiceDetail : Screen("service_detail/{serviceId}") {
        fun createRoute(serviceId: String) = "service_detail/$serviceId"
    }
}
