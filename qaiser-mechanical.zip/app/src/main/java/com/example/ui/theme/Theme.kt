package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GoldAccent,
    onPrimary = NavyDark,
    primaryContainer = NavySecondary,
    onPrimaryContainer = GoldLight,
    secondary = SlateBlue,
    onSecondary = Color.White,
    tertiary = GoldLight,
    background = CharcoalDark,
    onBackground = TextPrimaryDark,
    surface = CharcoalCardDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = CharcoalBorderDark,
    onSurfaceVariant = TextSecondaryDark,
    error = EmergencyRed,
    onError = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = SlateLight,
    onPrimaryContainer = NavyPrimary,
    secondary = SlateBlue,
    onSecondary = Color.White,
    tertiary = GoldAccent,
    background = SlateLight,
    onBackground = TextPrimaryLight,
    surface = SlateCardLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SlateBorderLight,
    onSurfaceVariant = TextSecondaryLight,
    error = EmergencyRed,
    onError = Color.White
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep automotive brand colors consistent
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun QaiserMechanicalTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MyApplicationTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

