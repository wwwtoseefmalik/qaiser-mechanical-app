package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AppUser
import com.example.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AuthUiState {
    object Idle : AuthUiState
    object Loading : AuthUiState
    data class Authenticated(val user: AppUser) : AuthUiState
    data class Error(val message: String) : AuthUiState
    data class ResetEmailSent(val email: String) : AuthUiState
}

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    val currentUser: StateFlow<AppUser?> = authRepository.currentUser

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                if (user != null) {
                    _uiState.value = AuthUiState.Authenticated(user)
                }
            }
        }
    }

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter both email and password")
            return
        }
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            val res = authRepository.login(email.trim(), pass)
            res.fold(
                onSuccess = { user ->
                    _uiState.value = AuthUiState.Authenticated(user)
                },
                onFailure = { err ->
                    _uiState.value = AuthUiState.Error(err.localizedMessage ?: "Login failed. Please check credentials.")
                }
            )
        }
    }

    fun register(name: String, email: String, pass: String, phone: String) {
        if (email.isBlank() || pass.isBlank() || name.isBlank()) {
            _uiState.value = AuthUiState.Error("Please fill in all required fields")
            return
        }
        if (pass.length < 6) {
            _uiState.value = AuthUiState.Error("Password must be at least 6 characters")
            return
        }
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            val res = authRepository.register(name.trim(), email.trim(), pass, phone.trim())
            res.fold(
                onSuccess = { user ->
                    _uiState.value = AuthUiState.Authenticated(user)
                },
                onFailure = { err ->
                    _uiState.value = AuthUiState.Error(err.localizedMessage ?: "Registration failed")
                }
            )
        }
    }

    fun forgotPassword(email: String) {
        if (email.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter your registered email address")
            return
        }
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            authRepository.sendPasswordReset(email.trim())
            _uiState.value = AuthUiState.ResetEmailSent(email)
        }
    }

    fun continueAsGuest() {
        authRepository.continueAsGuest()
    }

    fun logout() {
        authRepository.logout()
        _uiState.value = AuthUiState.Idle
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error || _uiState.value is AuthUiState.ResetEmailSent) {
            _uiState.value = AuthUiState.Idle
        }
    }
}
