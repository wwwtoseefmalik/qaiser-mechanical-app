package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.data.local.AppDatabase
import com.example.data.repository.AuthRepository
import com.example.data.repository.CarAdRepository
import com.example.data.repository.WorkshopRepository
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.QaiserMechanicalTheme
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.EmergencyViewModel
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.WorkshopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val authRepository = AuthRepository()
        val carAdRepository = CarAdRepository(database.carAdDao())
        val workshopRepository = WorkshopRepository()

        setContent {
            QaiserMechanicalTheme {
                val navController = rememberNavController()

                val authViewModel = remember { AuthViewModel(authRepository) }
                val marketplaceViewModel = remember { MarketplaceViewModel(carAdRepository) }
                val workshopViewModel = remember { WorkshopViewModel(workshopRepository) }
                val emergencyViewModel = remember { EmergencyViewModel(workshopRepository) }

                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigation(
                        navController = navController,
                        authViewModel = authViewModel,
                        marketplaceViewModel = marketplaceViewModel,
                        workshopViewModel = workshopViewModel,
                        emergencyViewModel = emergencyViewModel
                    )
                }
            }
        }
    }
}
