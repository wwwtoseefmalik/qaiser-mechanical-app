package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object ContactHelper {
    const val QAISER_PHONE_NUMBER = "+923214813830"
    const val QAISER_PHONE_CLEAN = "923214813830"
    const val WORKSHOP_NAME = "Qaiser Mechanical Auto Workshop"
    const val WORKSHOP_ADDRESS = "Qaiser Mechanical Workshop, Main Automotive Market, Lahore, Pakistan"

    fun callMechanic(context: Context, phoneNumber: String = QAISER_PHONE_NUMBER) {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsApp(context: Context, phoneNumber: String = QAISER_PHONE_CLEAN, message: String = "") {
        try {
            val cleanNumber = phoneNumber.replace("+", "").replace("-", "").replace(" ", "").trim()
            val finalNumber = if (cleanNumber.startsWith("0")) {
                "92" + cleanNumber.substring(1)
            } else cleanNumber

            val encodedMsg = Uri.encode(message)
            val uri = Uri.parse("https://wa.me/$finalNumber?text=$encodedMsg")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open WhatsApp: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendBreakdownLocationOnWhatsApp(
        context: Context,
        carModel: String,
        issue: String,
        details: String,
        latitude: Double?,
        longitude: Double?,
        address: String? = null
    ) {
        val locationText = if (latitude != null && longitude != null) {
            "📍 GPS Location (گوگل میپ لوکیشن):\nhttps://maps.google.com/?q=$latitude,$longitude"
        } else {
            "📍 Location: $address (GPS not available)"
        }

        val message = buildString {
            append("🚨 *EMERGENCY BREAKDOWN - QAISER MECHANICAL*\n")
            append("السلام علیکم قیصر بھائی! ہماری گاڑی خراب ہو گئی ہے۔ برائے مہربانی یہاں آکر ٹھیک کر دیں یا مکینک بھیجیں۔\n\n")
            if (carModel.isNotBlank()) append("🚗 *Car:* $carModel\n")
            if (issue.isNotBlank()) append("⚠️ *Issue:* $issue\n")
            if (details.isNotBlank()) append("📝 *Details:* $details\n")
            append("\n$locationText\n\n")
            append("Sent via *Qaiser Mechanical App*")
        }

        openWhatsApp(context, QAISER_PHONE_CLEAN, message)
    }

    fun contactSellerForCarAd(context: Context, sellerPhone: String, carTitle: String, priceFormatted: String, adId: String) {
        val message = buildString {
            append("السلام علیکم! I saw your car ad on *Qaiser Mechanical Marketplace*:\n\n")
            append("🚗 *Car:* $carTitle\n")
            append("💰 *Demand:* $priceFormatted\n")
            append("🆔 *Ad Ref:* $adId\n\n")
            append("Is this vehicle still available for inspection and deal?")
        }
        openWhatsApp(context, sellerPhone, message)
    }

    fun bookServiceOnWhatsApp(context: Context, serviceTitle: String, carModel: String, preferredDate: String) {
        val message = buildString {
            append("السلام علیکم قیصر مکینیکل! I would like to book a service appointment at your workshop:\n\n")
            append("🔧 *Service:* $serviceTitle\n")
            if (carModel.isNotBlank()) append("🚗 *Vehicle:* $carModel\n")
            if (preferredDate.isNotBlank()) append("📅 *Preferred Time/Date:* $preferredDate\n\n")
            append("Please confirm workshop slot availability.")
        }
        openWhatsApp(context, QAISER_PHONE_CLEAN, message)
    }

    fun openWorkshopLocationOnMap(context: Context) {
        try {
            val gmmIntentUri = Uri.parse("geo:31.5204,74.3587?q=Qaiser+Mechanical+Workshop+Lahore")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            Toast.makeText(context, WORKSHOP_ADDRESS, Toast.LENGTH_LONG).show()
        }
    }
}
